<!DOCTYPE html>
<html>
<head>
	<title>Login Form Design</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<DIV class="loginbox">
			<img src="avatar.png" class="avatar">
			<h1>Registrtion</h1>
				<form>
					<!-- <p>first name</p>
					<input type="text" name="" placeholder="Enter Username"><br>
					<br>
					<p>Password</p>
					<input type="Password" name="" placeholder="Enter Password"><br>
					<br>
					<input type="submit" name="" value="Login"><br>
					<br>
					<a href="E:\project\Login Form Design_files\forget password\forgret.html">Lost your Password?</a><br>
					<a href="E:\project\Login Form Design_files\next to login(option)\option.html">Don't have an account?</a> -->


					<label>first name:</label>
				 <input type="text" name="firstname" class="form-control"><br>

				 <label>last name:</label>
				 <input type="text" name="lastname" class="form-control"><br>

				 <label>surnamename:</label>
				 <input type="text" name="surname" class="form-control"><br>

				 <label>DOB:</label>
				 <input type="text" name="dob" class="form-control"><br>

				 <label>Mobile number:</label>
				 <input type="text" name="mobile" class="form-control"><br>

				 <label>Email:</label>
				 <input type="text" name="email" class="form-control"><br>

				 <label>Password:</label>
				 <input type="text" name="password" class="form-control">

				</form>


<?php 

$host="localhost";
$user="root";
$password="";
$db="demo";

mysql_connect($host,$user,$password);
mysql_select_db($db);

if(isset($_POST['username'])){
    
    $uname=$_POST['username'];
    $password=$_POST['password'];
    
    $sql="select * from loginform where user='".$uname."'AND Pass='".$password."' limit 1";
    
    $result=mysql_query($sql);
    
    if(mysql_num_rows($result)==1){
        echo " You Have Successfully Logged in";
        exit();
    }
    else{
        echo " You Have Entered Incorrect Password";
        exit();
    }
        
}
?>
		</DIV>
</body>
</html>