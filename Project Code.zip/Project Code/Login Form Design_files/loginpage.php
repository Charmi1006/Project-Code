<!DOCTYPE html>
<html>
<head>
	<?php
	<title>Login Form Design</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<DIV class="loginbox">
			<img src="avatar.png" class="avatar">
			<h1>Login Here</h1>
				<form>
					<p>Username</p>
					<input type="text" name="" placeholder="Enter Username"><br>
					<br>
					<p>Password</p>
					<input type="Password" name="" placeholder="Enter Password"><br>
					<br>
					<input type="submit" name="" value="Login"><br>
					<br>
					<a href="E:\project\Login Form Design_files\forget password\forgret.html">Lost your Password?</a><br>
					<a href="E:\project\Login Form Design_files\next to login(option)\option.html">Don't have an account?</a>

				</form>
?>
		</DIV>
</body>
</html>